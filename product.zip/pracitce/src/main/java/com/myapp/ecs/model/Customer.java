package com.myapp.ecs.model;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pc_products")
public class Customer {
	 @Id 
	 @Column(name="id")
	 private int CustomerId;
		
	 private String fname;	 
     private String lname;
     private double Total;
     private String email;
     private String Address;
     private String mobile;
     
     public Customer() {
    	 this.CustomerId=new Random().nextInt(100000);
     }

	public Customer(String fname, String lname,String email, double Total,String Address, String mobile) {
		this.CustomerId=new Random().nextInt(100000);
		this.fname = fname;
		this.lname = lname;
		this.email=  email;
		this.Address = Address;
		this.mobile = mobile;
		this.Total= Total;
	}

	public int getCustomerId() {
		return CustomerId;
	}

	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public double getTotal() {
		return Total;
	}

	public void setTotal(double total) {
		Total = total;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "Employee [CustomerId=" + CustomerId + ", fname=" + fname + ", lname=" + lname + ", Total=" + Total
				+ ", email=" + email + ", Address=" + Address+ ", mobile=" + mobile +"]";
	}
    
}
