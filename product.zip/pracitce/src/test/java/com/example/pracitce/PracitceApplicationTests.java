package com.example.pracitce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracitceApplicationTests {

	@Test
	void contextLoads() {
	}

}
